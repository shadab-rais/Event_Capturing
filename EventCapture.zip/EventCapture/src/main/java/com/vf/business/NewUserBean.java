
package com.vf.business;

/**
 *
 * @author shadab rais
 */
public class NewUserBean {
 
    private String empId;
    private String empName;
    private String mobNO; 
    public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getMobNO() {
		return mobNO;
	}
	public void setMobNO(String mobNO) {
		this.mobNO = mobNO;
	}
	public boolean isValid() {
		return valid;
	}
	public void setValid(boolean valid) {
		this.valid = valid;
	}
	public boolean valid;

    
}
 

