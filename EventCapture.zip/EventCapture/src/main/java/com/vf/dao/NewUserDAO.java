package com.vf.dao;

import com.vf.business.NewUserBean;
import com.vf.business.UserBean;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.*;
import com.vf.utility.ConnectionManager;

/**
 *
 * @author shadab rais
 */
public class NewUserDAO {

    static Connection currentCon = null;
    static ResultSet rs = null;

    public static NewUserBean adduser(NewUserBean bean) {

        //preparing some objects for connection 
        Statement stmt = null;
        String id = bean.getEmpId();
        String name = bean.getEmpName();
        String mob = bean.getMobNO();

        String searchQuery
                = "INSERT INTO employee (Employee_id , Employee_Name , Mobile_number)"
                + " VALUES (?, ?, ?)";
        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Your user name is " + name);
        System.out.println("Your id is " + id);
        System.out.println("Query: " + searchQuery);

        try {
            currentCon = ConnectionManager.getConnection();
            PreparedStatement preparedStatement = null;
            int recordsAdded = 0;
            preparedStatement = currentCon.prepareStatement(searchQuery);
            preparedStatement.setString(1, bean.getEmpId());
            preparedStatement.setString(2, bean.getEmpName());
            preparedStatement.setString(3, bean.getMobNO());

            recordsAdded = preparedStatement.executeUpdate();

            if (recordsAdded > 0) {
                //System.out.println("Sorry, you are not a registered user! Please sign up first");
                bean.setValid(true);
            } //if user exists set the isValid variable to true
            else {

                bean.setValid(false);
            }
        } catch (SQLException e) {
            System.out.println("Error executing " + searchQuery + " statement: "
                    + e.getMessage());
            //return 0;
        } finally {

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return bean;

    }

   /* public static NewUserBean getuser(NewUserBean bean) {

        //preparing some objects for connection 
        Statement stmt = null;
        String id = bean.getEmpId();
        String name = bean.getEmpName();
        String mob = bean.getMobNO();

        String searchQuery
                = "select * from users where id='"
                +id
                + "'";

        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Your user id is " +id );
        System.out.println("Your name is " + name);
        System.out.println("Query: " + searchQuery);

        try {
            //connect to DB 
            currentCon = ConnectionManager.getConnection();
            stmt = currentCon.createStatement();
            rs = stmt.executeQuery(searchQuery);
            if (rs.next()) {
                bean.setEmpId(rs.getString("id"));
            }
           
        } catch (Exception ex) {
            System.out.println("Log In failed: An Exception has occurred! " + ex);
        } //some exception handling
        finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (Exception e) {
                }
                rs = null;
            }

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return bean;
    }*/
}
