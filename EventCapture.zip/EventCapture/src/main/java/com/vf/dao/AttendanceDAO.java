package com.vf.dao;

import com.vf.business.NewUserBean;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.vf.utility.ConnectionManager;
import com.vf.business.AttendanceBean;
import java.util.Calendar;
/**
 *
 * @author shadab rais
 */
public class AttendanceDAO {
    static Connection currentCon = null;
    static ResultSet rs = null;

    public static AttendanceBean addempattnd(AttendanceBean bean) {

        //preparing some objects for connection 
        Statement stmt = null;
        
        String id = bean.getEmpId();
        String date = bean.getDt();
        String time = bean.getTime();
         
        
        /*Calendar calendar = Calendar.getInstance();
        java.sql.Timestamp ourJavaTimestampObject = new java.sql.Timestamp(calendar.getTime().getTime());*/
        String searchQuery
                = "INSERT INTO attendance (Employee_id , Date_of_swipe , Time_of_swipe)"
                + " VALUES (?,?,?)";
        // "System.out.println" prints in the console; Normally used to trace the process
        System.out.println("Your user name is " + id );
        System.out.println("Your login time  is " + time);
        System.out.println("Your login time  is " + date);
        System.out.println("Query: " + searchQuery);

        try {
            currentCon = ConnectionManager.getConnection();
            PreparedStatement preparedStatement = null;
            int recordsAdded = 0;
            preparedStatement = currentCon.prepareStatement(searchQuery);
            preparedStatement.setString(1,id);
            preparedStatement.setString(2, date);
            preparedStatement.setString(3, time);
            

            recordsAdded = preparedStatement.executeUpdate();

           if (recordsAdded > 0) {
               
                bean.setValid(true);
            } 
            else {
            //	System.out.println("hurra, you are accessed");
               bean.setValid(false);
            }
        } catch (SQLException e) {
            System.out.println("Error executing " + searchQuery + " statement: "
                    + e.getMessage());
            //return 0;
        } finally {

            if (stmt != null) {
                try {
                    stmt.close();
                } catch (Exception e) {
                }
                stmt = null;
            }

            if (currentCon != null) {
                try {
                    currentCon.close();
                } catch (Exception e) {
                }

                currentCon = null;
            }
        }

        return bean;

    }

}
